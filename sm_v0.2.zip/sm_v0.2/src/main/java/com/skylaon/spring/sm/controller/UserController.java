package com.skylaon.spring.sm.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.skylaon.spring.sm.service.MemberService;
import com.skylaon.spring.sm.vo.MemberVO;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/login/*")
@AllArgsConstructor
@Controller
public class UserController {
	private MemberService service;

	@RequestMapping("/login")
	public void login() {

	}

	@RequestMapping("/loginproc")
	public String loginProc(HttpSession s, MemberVO uvo) {
		MemberVO isLogin = service.login(uvo);
		if (isLogin != null) {
			log.info(isLogin.getU_name());
			s.setAttribute("user", isLogin);
		} else {
			log.info("회원정보 널값임");
		}
		return "redirect:/guest/getList";
	}

	@RequestMapping("/logout")
	public String loginProc(HttpSession s) {
		s.invalidate();
		return "redirect:/";
	}

	public void regProc(MemberVO m, Model model) {
		// todo
		log.info("====================");

		System.out.println("==== id:" + m.getU_id());
		System.out.println("==== pw:" + m.getU_pw());
	}

}
