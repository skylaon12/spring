package com.skylaon.spring.sm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.skylaon.spring.sm.mapper.MemberMapper;
import com.skylaon.spring.sm.vo.MemberVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class MemberServiceImpl implements MemberService{

	@Setter(onMethod_ = @Autowired)
	private MemberMapper mapper;
	
	@Override
	public MemberVO login(MemberVO uvo) {
		log.info("로그인 service 진입");
		log.info("아이디 = " + uvo.getU_id());
		log.info("비밀번호 = " + uvo.getU_pw());
		MemberVO vo = mapper.login(uvo);
		if(vo != null) {
			log.info("DB에서 가져온 아이디 : " + vo.getU_id());
			log.info("DB에서 가져온 패스워드 : " + vo.getU_pw());
		}else {
			log.info("매퍼에서 못가져옴");
		}
		
		return vo;
	}

}
