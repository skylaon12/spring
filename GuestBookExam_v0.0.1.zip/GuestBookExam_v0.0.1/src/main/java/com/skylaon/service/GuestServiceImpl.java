package com.skylaon.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.skylaon.domain.GuestVO;
import com.skylaon.mapper.GuestMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class GuestServiceImpl implements GuestService{
	
	@Setter(onMethod_ = @Autowired)
	private GuestMapper mapper;
	
	// 리스트
	@Override
	public List<GuestVO> getList() {
		log.info("비지니스 계층========");
		return mapper.getList();
	}

	// 읽기
	@Override
	public GuestVO read(long bno) {
		return mapper.read(bno);
	}

	@Override
	public void del(long bno) {
		mapper.del(bno);
	}

	@Override
	public void write(GuestVO gvo) {
		mapper.write(gvo);
	}

	@Override
	public void modify(GuestVO gvo) {
		mapper.modify(gvo);
	}


}
