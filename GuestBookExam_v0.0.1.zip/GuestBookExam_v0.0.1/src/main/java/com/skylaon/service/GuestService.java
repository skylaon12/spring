package com.skylaon.service;

import java.util.List;

import com.skylaon.domain.GuestVO;

public interface GuestService {
	public List<GuestVO> getList();	// 리스트
	public GuestVO read(long bno);	// read
	public void del(long bno); 		// delete
	public void write(GuestVO gvo);	// write
	public void modify(GuestVO gvo);// update
}
