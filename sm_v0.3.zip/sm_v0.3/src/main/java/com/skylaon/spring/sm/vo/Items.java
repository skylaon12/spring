
package com.skylaon.spring.sm.vo;

import java.util.List;

public class Items {

    public List<Item> item;

}
