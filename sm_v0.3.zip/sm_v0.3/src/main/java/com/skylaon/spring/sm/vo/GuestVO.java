package com.skylaon.spring.sm.vo;

import lombok.Data;

@Data
public class GuestVO {
	
	private Long bno;
	private String btext;
}
